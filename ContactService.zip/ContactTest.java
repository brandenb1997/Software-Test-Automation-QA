import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {
//test new contact
	@Test
	void testContacts() {
		Contact contact = new Contact("12345", "Branden", "Boehnke", "1234567890", "123 City Ave");
        assertEquals("12345", contact.getContactID());
        assertEquals("Branden", contact.getFirstName());
        assertEquals("Boehnke", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 City Ave", contact.getAddress());
	}

}
