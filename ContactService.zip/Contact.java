
public class Contact {
	//contact information
	private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	//constructor for contact with restriction exceptions
	public Contact(String contactID, String firstName, String lastName, String phone, String address) {
		//exception if contactID is null or greater than 10 characters
		if(contactID == null || contactID.length()>10 ) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		//exception if firstName is null or greater than 10 characters
		if(firstName == null || firstName.length()>10 ) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		//exception if lastName is null or greater than 10 characters
		if(lastName == null || lastName.length()>10 ) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		//exception if phone is null, greater than, or less than 10 characters
		if(phone == null || phone.length()>10 || phone.length()<10 ) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		//exception if address is null or greater than 30 characters
		if(address == null || address.length()>30 ) {
			throw new IllegalArgumentException("Invalid Address");
		}
		
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	
	// Getter methods for contactID, firstName, lastName, phone and address
	public String getContactID() {
		return contactID;
	}
	
	public String getFirstName() {
		return firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getAddress() {
		return address;
	}
	
	// Setter methods for firstName, lastName, phone and address
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
}
