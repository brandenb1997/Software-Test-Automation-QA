import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
	private ContactService contactService;
//method for preparing conditions before test cases
	@BeforeEach
	void testPrep() {
		contactService = new ContactService();
        // Adding some initial contacts for testing
        contactService.addContact(new Contact("1", "Billy", "Joel", "2345678901", "456 Hollywood Blvd"));
        contactService.addContact(new Contact("2", "James", "Dean", "4567890123", "789 Stergus St"));
    }

    // Test case to verify contact deletion
    @Test
    public void testDeleteContact() {
        contactService.deleteContact("1");
        assertNull(contactService.getContact("1"));
    }

    // Test case to verify contact update
    @Test
    public void testUpdateContact() {
        contactService.updateContact("2", "James", "Dean", "4567890123", "991 Shogun Ave");
        Contact updatedContact = contactService.getContact("2");
        assertEquals("James", updatedContact.getFirstName());
        assertEquals("Dean", updatedContact.getLastName());
        assertEquals("4567890123", updatedContact.getPhone());
        assertEquals("991 Shogun Ave", updatedContact.getAddress());
    }
}
