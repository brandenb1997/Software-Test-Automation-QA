import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private Map<String, Contact> contacts;
//create new hashmap for contacts
    public ContactService() {
        this.contacts = new HashMap<>();
    }
//add contact method
    public void addContact(Contact contact) {
        contacts.put(contact.getContactID(), contact);
    }
//delete contact method
    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }
//update contact method
    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        if (contacts.containsKey(contactID)) {
            Contact contact = contacts.get(contactID);
            if (firstName != null) {
                contact.setFirstName(firstName);
            }
            if (lastName != null) {
                contact.setLastName(lastName);
            }
            if (phone != null) {
                contact.setPhone(phone);
            }
            if (address != null) {
                contact.setAddress(address);
            }
        }
    }
//get contact method
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}
